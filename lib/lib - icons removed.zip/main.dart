import 'package:google_sign_in_dartio/google_sign_in_dartio.dart';
import 'package:window_size/window_size.dart';
import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'UIs/home.dart';
import 'utils/google_sign_in_service.dart';
import 'UIs/login.dart';

void main() async {
  try {
    if (Platform.isWindows) {
      setWindowTitle("LayersTex");
      GoogleSignInDart.register(
          clientId: "1032472887946-40i5mbtk3lf2b6dbasgirnrlknjao3dh.apps.googleusercontent.com");
    }
  } catch (_) {}
  dynamic redirect = const LoginUI();
  dynamic userObj = await ggSignInSilent();
  if (userObj != false) {
    redirect = HomePageUI(userObj: userObj);
  }
  runApp(MaterialApp(
      theme: ThemeData(
        brightness: Brightness.light,
        colorSchemeSeed: Colors.purple,
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
          brightness: Brightness.dark, colorSchemeSeed: Colors.purple, useMaterial3: true),
      themeMode: ThemeMode.system,
      debugShowCheckedModeBanner: false,
      home: redirect));
}
